package edu.usc.irds;

import java.io.IOException;
import java.io.InputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.File;
import java.util.Collections;
import java.util.Set;

import org.apache.tika.exception.TikaException;
import org.apache.tika.metadata.Metadata;
import org.apache.tika.mime.MediaType;
import org.apache.tika.parser.ParseContext;
import org.apache.tika.parser.AbstractParser;
import org.apache.tika.parser.pdf.PDFParser;
import org.apache.tika.sax.BodyContentHandler;
import org.xml.sax.ContentHandler;
import org.xml.sax.SAXException;

public class UFOPDFParser extends AbstractParser {

        private static final Set<MediaType> SUPPORTED_TYPES = Collections.singleton(MediaType.application("pdf"));
        public static final String PDF_MIME_TYPE = "application/pdf";
        
        public Set<MediaType> getSupportedTypes(ParseContext context) {
                return SUPPORTED_TYPES;
        }

        public void parse(
                    InputStream stream, ContentHandler handler,
                    Metadata metadata, ParseContext context)
                    throws IOException, SAXException, TikaException {

            metadata.set(Metadata.CONTENT_TYPE, PDF_MIME_TYPE);
            metadata.set("Group", "13");
            metadata.set("Course", "CSCI599");
            metadata.set("Academic Year", "Spring 2018");
            BodyContentHandler bodyContentHandler = new BodyContentHandler();
            PDFParser pdfparser = new PDFParser(); 
            pdfparser.parse(stream, bodyContentHandler, metadata, context);
           
            String outputDir = System.getProperty("pdfContentOutputDir");
            if(outputDir == null || outputDir.isEmpty()) {
                throw new TikaException("Please specify pdfContentOutputDir");
            }
            String content = bodyContentHandler.toString();
            if(createFolderIfNotExist(outputDir)) {
                String resourceName = metadata.get("resourceName");
                String fileName = resourceName.substring(0,resourceName.lastIndexOf("."));
                writeToFile(outputDir + "/" + fileName +".txt", content);
            }
        }
        private void writeToFile(String fileName, String content) throws IOException, FileNotFoundException {
            FileOutputStream outputStream = new FileOutputStream(fileName);
            byte[] strToBytes = content.getBytes();
            outputStream.write(strToBytes);
        
            outputStream.close();
        }
        private boolean createFolderIfNotExist(String dir) {
            File theDir = new File(dir);
            // if the directory does not exist, create it
            if (!theDir.exists()) {
                try{
                    theDir.mkdir();
                    return true;
                } 
                catch(SecurityException se){
                }        
                return false;
            }
            return true;
        }
}