#!/bin/bash
set -e

psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" <<-EOSQL
    DROP TABLE IF EXISTS descriptors;
    CREATE TABLE IF NOT EXISTS descriptors (
      type_str  TEXT  NOT NULL,
      uid       TEXT  NOT NULL,
      vector    BYTEA NOT NULL,

      PRIMARY KEY (uid, type_str)
    );
    DROP TABLE IF EXISTS descriptor_index;
    CREATE TABLE IF NOT EXISTS descriptor_index (
      uid       TEXT  NOT NULL,
      element   BYTEA NOT NULL,

      PRIMARY KEY (uid)
    );

EOSQL
